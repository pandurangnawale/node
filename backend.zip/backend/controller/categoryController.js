var cagetory = require('../model/category.js');
exports.getCategory = (req, res, next) => {
    cagetory.find(function (err, cagetory) {
        if (err) {
            res.json(err)
        } else {
            res.json(cagetory);
        }
    })
};
exports.addCategories = (req, res, next) => {
    let newCategory = new cagetory({
        categoryId: req.body.categoryId,
        categoryName: req.body.categoryName,
        created_At: new Date,
        updated_At: new Date
    });
    newCategory.save((err, item) => {
        if (err) {
            res.json(err);
        } else {
            res.json({
                msg: "Category added Successfully"
            });
        }
    })
};
exports.updateCategory = (req, res, next) => {
    cagetory.findOneAndUpdate({
            "cagetoryId": req.body.cagetoryId
        }, {
            $set: {
                categoryName: req.body.categoryName,
                created_At: new Date(),
                updated_At: new Date()
            }
        },
        function (err, result) {
            if (err) {
                res.json(err)
            } else {
                res.json({
                    msg: "Record Updated"
                })
            }
        }
    )

};