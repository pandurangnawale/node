var express = require('express');
var router = express.Router();
var category = require('../controller/categoryController.js');
router.get('/cotegories', category.getCategory);
router.post('/cotegoryData', category.addCategories);
router.put('/cotegoryUpdated', category.updateCategory);

module.exports = router;