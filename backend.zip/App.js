var express = require('express');
var mongoose = require('mongoose');
var bodyParser = require('body-parser')

var app = express();
app.use(bodyParser.json());
var routes = require('./backend/route/route');
app.listen(3004);
console.log('Server connected');

mongoose.connect('mongodb://localhost:27017/expenselist', {
    useNewUrlParser: true,
    useUnifiedTopology: true
});
mongoose.connection.on('connected', () => {
    console.log('connected with port 27012')
});
mongoose.connection.on('error', (error) => {
    console.log(error)
})
app.use('/routes', routes);

module.exports = app;